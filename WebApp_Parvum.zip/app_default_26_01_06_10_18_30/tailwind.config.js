/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#fdf8f6',
          100: '#f2e8e5',
          200: '#eaddd7',
          300: '#e0c8b2',
          400: '#d4a373',
          500: '#bc6c25',
          600: '#a65d20',
          700: '#8b4d1a',
          800: '#6f3d15',
          900: '#522e10',
        },
        accent: '#D4AF37', // Gold
      },
      fontFamily: {
        serif: ['Playfair Display', 'serif'],
        sans: ['Inter', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
