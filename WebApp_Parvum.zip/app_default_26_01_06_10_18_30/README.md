# Aura Essence - Premium Perfume E-Commerce

Aura Essence is a sophisticated, digital business-ready e-commerce platform for luxury fragrances. It features a high-end "digital business" aesthetic, full shopping workflow, and a robust administrative dashboard.

## ✨ Key Features

### Customer Experience
- **Luxury Catalog**: Filterable and searchable fragrance gallery.
- **Dynamic Cart**: Real-time updates with persistent storage.
- **Secure Checkout**: Streamlined multi-step checkout simulation.
- **Responsive Design**: Optimized for mobile, tablet, and desktop.
- **Role-based Navigation**: Dynamic headers based on user status.

### Admin Experience
- **Insights Dashboard**: Visual stats for revenue, orders, and inventory.
- **Inventory Management**: Full CRUD (Create, Read, Update, Delete) for fragrances.
- **Order Control**: Manage order statuses (Pending, Paid, Shipped) and direct WhatsApp customer integration.
- **Low Stock Alerts**: Automated warnings for inventory management.

## 🛠️ Tech Stack
- **React 18** (Vite-powered)
- **Tailwind CSS** (Premium styling)
- **Lucide React** (Iconography)
- **Context API** (State management for Auth and Cart)
- **LocalStorage Service Layer** (Simulated backend)

## 🚀 Installation & Setup

1.  **Clone or download** the project folder.
2.  **Open terminal** in the project root.
3.  **Install dependencies**:
    npm install
4.  **Start development server**:
    npm run dev
5.  **Build for production**:
    npm run build

## 🔑 Access Credentials

### Admin Access
- **Email**: `admin@aura.com`
- **Password**: `admin123`

### Customer Access
- **Email**: Any email (e.g., `user@example.com`)
- **Password**: `password`

## 📁 Project Structure
- `src/context/`: Global state (Auth/Cart).
- `src/services/`: Simulated API calls and data management.
- `src/layouts/`: Component wrappers for Admin vs Customer views.
- `src/pages/`: Individual view components.
- `src/index.css`: Tailwind custom configurations and fonts.

## 📝 Usage Notes
- The application uses `localStorage` to persist data. Your products and orders will stay saved in your browser even after a refresh.
- To reset the application data, clear your browser's local storage or use a private window.
- Image assets are powered by high-quality Unsplash CDN links.
