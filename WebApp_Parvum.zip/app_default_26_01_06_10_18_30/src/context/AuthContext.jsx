import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem('aura_essence_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setLoading(false);
  }, []);

  const login = (email, password) => {
    // Simulated auth logic
    let role = 'customer';
    if (email === 'admin@aura.com' && password === 'admin123') {
      role = 'admin';
    } else if (password !== 'password') {
       throw new Error('Invalid credentials. Use any email and "password" for customer or admin@aura.com / admin123 for admin.');
    }

    const userData = {
      id: role === 'admin' ? 'admin-1' : 'user-' + Math.random().toString(36).substr(2, 9),
      email,
      name: role === 'admin' ? 'System Administrator' : email.split('@')[0],
      role
    };

    setUser(userData);
    localStorage.setItem('aura_essence_user', JSON.stringify(userData));
    return userData;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('aura_essence_user');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
