import React from 'react';
import { Package, ShoppingBag, DollarSign, Users } from 'lucide-react';
import { productService } from '../../services/productService';
import { orderService } from '../../services/orderService';

const Dashboard = () => {
  const products = productService.getProducts();
  const orders = orderService.getOrders();
  
  const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);
  const lowStock = products.filter(p => p.stock < 10).length;

  const stats = [
    { label: 'Total Revenue', val: `$${totalRevenue.toFixed(0)}`, icon: <DollarSign />, color: 'text-green-600 bg-green-50' },
    { label: 'Total Orders', val: orders.length, icon: <ShoppingBag />, color: 'text-blue-600 bg-blue-50' },
    { label: 'Active Products', val: products.length, icon: <Package />, color: 'text-purple-600 bg-purple-50' },
    { label: 'Low Stock Items', val: lowStock, icon: <Users />, color: 'text-amber-600 bg-amber-50' },
  ];

  return (
    <div>
      <h2 className="text-3xl font-serif mb-8">Admin Dashboard</h2>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
        {stats.map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
            <div className={`w-12 h-12 rounded-lg flex items-center justify-center mb-4 ${stat.color}`}>
              {React.cloneElement(stat.icon, { size: 24 })}
            </div>
            <p className="text-slate-400 text-sm font-medium">{stat.label}</p>
            <h4 className="text-2xl font-bold mt-1">{stat.val}</h4>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Orders */}
        <div className="bg-white p-8 rounded-xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold mb-6">Recent Orders</h3>
          <div className="space-y-4">
            {orders.slice(0, 5).map(order => (
              <div key={order.id} className="flex justify-between items-center py-3 border-b border-slate-50 last:border-0">
                <div>
                  <p className="font-bold text-sm">{order.id}</p>
                  <p className="text-xs text-slate-400">{new Date(order.createdAt).toLocaleDateString()}</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-sm">${order.total}</p>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full uppercase font-bold ${
                    order.status === 'Pending' ? 'bg-amber-100 text-amber-700' : 'bg-green-100 text-green-700'
                  }`}>
                    {order.status}
                  </span>
                </div>
              </div>
            ))}
            {orders.length === 0 && <p className="text-slate-400 italic text-sm">No orders yet.</p>}
          </div>
        </div>

        {/* Inventory Alert */}
        <div className="bg-white p-8 rounded-xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold mb-6">Inventory Alerts</h3>
          <div className="space-y-4">
            {products.filter(p => p.stock < 10).map(p => (
              <div key={p.id} className="flex items-center space-x-4">
                <img src={p.image} className="w-10 h-10 object-cover rounded" />
                <div className="flex-grow">
                  <p className="text-sm font-medium">{p.name}</p>
                  <div className="w-full bg-slate-100 h-1.5 rounded-full mt-1 overflow-hidden">
                    <div 
                      className="bg-red-500 h-full rounded-full" 
                      style={{ width: `${(p.stock / 20) * 100}%` }}
                    ></div>
                  </div>
                </div>
                <span className="text-xs font-bold text-red-500">{p.stock} left</span>
              </div>
            ))}
            {lowStock === 0 && <p className="text-slate-400 italic text-sm">All items well stocked.</p>}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
