import React, { useState, useEffect } from 'react';
import { MessageCircle, ExternalLink, Filter } from 'lucide-react';
import { orderService } from '../../services/orderService';

const OrderManagement = () => {
  const [orders, setOrders] = useState([]);
  const [filter, setFilter] = useState('All');

  useEffect(() => {
    setOrders(orderService.getOrders());
  }, []);

  const handleStatusUpdate = (id, status) => {
    const updated = orderService.updateOrderStatus(id, status);
    setOrders(updated);
  };

  const filteredOrders = filter === 'All' ? orders : orders.filter(o => o.status === filter);

  const getWhatsAppLink = (order) => {
    const text = encodeURIComponent(`Hi ${order.customer.name}, regarding your Aura Essence order ${order.id}. We have received your payment.`);
    return `https://wa.me/${order.customer.phone.replace(/[^0-9]/g, '')}?text=${text}`;
  };

  return (
    <div>
      <div className="flex justify-between items-end mb-8">
        <div>
          <h2 className="text-3xl font-serif">Order Management</h2>
          <p className="text-slate-400 text-sm italic">Manage fulfillment and payments</p>
        </div>
        <div className="flex items-center space-x-2">
          <Filter size={16} className="text-slate-400" />
          <select 
            className="bg-transparent border-none text-sm font-bold uppercase tracking-widest focus:ring-0 cursor-pointer"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          >
            <option>All</option>
            <option>Pending</option>
            <option>Paid</option>
            <option>Shipped</option>
            <option>Cancelled</option>
          </select>
        </div>
      </div>

      <div className="space-y-6">
        {filteredOrders.map(order => (
          <div key={order.id} className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
            <div className="p-6 border-b border-slate-50 flex flex-wrap justify-between items-center gap-4">
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Order Ref</span>
                <h4 className="font-bold text-slate-800">{order.id}</h4>
              </div>
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Customer</span>
                <p className="text-sm">{order.customer.name}</p>
              </div>
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Total Amount</span>
                <p className="text-sm font-bold text-slate-900">${order.total.toFixed(2)}</p>
              </div>
              <div className="flex items-center space-x-4">
                <select 
                  className={`text-[10px] font-bold uppercase py-1 px-3 rounded-full border-none ring-1 ring-slate-200 cursor-pointer ${
                    order.status === 'Pending' ? 'bg-amber-50 text-amber-700' : 
                    order.status === 'Paid' ? 'bg-blue-50 text-blue-700' : 'bg-green-50 text-green-700'
                  }`}
                  value={order.status}
                  onChange={(e) => handleStatusUpdate(order.id, e.target.value)}
                >
                  <option>Pending</option>
                  <option>Paid</option>
                  <option>Shipped</option>
                  <option>Cancelled</option>
                </select>
                <a 
                  href={getWhatsAppLink(order)} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-green-600 hover:text-green-700 transition-colors p-2 bg-green-50 rounded-lg"
                  title="Contact via WhatsApp"
                >
                  <MessageCircle size={20} />
                </a>
              </div>
            </div>
            
            <div className="p-6 bg-slate-50/50 grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4">Items Ordered</p>
                <div className="space-y-3">
                  {order.items.map(item => (
                    <div key={item.id} className="flex justify-between text-xs">
                      <span className="text-slate-600 italic">{item.quantity}x {item.name}</span>
                      <span className="font-medium">${(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="text-xs">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4">Shipping Details</p>
                <p className="text-slate-600">{order.customer.address}</p>
                <p className="text-slate-600">{order.customer.city}</p>
                <p className="text-slate-600 mt-2 font-bold">{order.customer.phone}</p>
                <p className="mt-4 text-slate-400">Payment: {order.customer.paymentMethod}</p>
              </div>
            </div>
          </div>
        ))}
        {filteredOrders.length === 0 && (
          <div className="text-center py-20 bg-white rounded-xl border border-dashed border-slate-200">
            <p className="text-slate-400 italic">No orders found in this category.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default OrderManagement;
