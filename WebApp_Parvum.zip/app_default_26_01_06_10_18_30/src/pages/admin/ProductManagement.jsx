import React, { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, X } from 'lucide-react';
import { productService } from '../../services/productService';

const ProductManagement = () => {
  const [products, setProducts] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [formData, setFormData] = useState({
    name: '', brand: '', price: '', category: 'Intense', stock: '', description: '', image: ''
  });

  useEffect(() => {
    setProducts(productService.getProducts());
  }, []);

  const handleOpenModal = (prod = null) => {
    if (prod) {
      setEditingProduct(prod);
      setFormData(prod);
    } else {
      setEditingProduct(null);
      setFormData({ name: '', brand: '', price: '', category: 'Intense', stock: '', description: '', image: 'https://images.unsplash.com/photo-1557170334-a9632e77c6e4?auto=format&fit=crop&q=80&w=800' });
    }
    setIsModalOpen(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const updated = productService.saveProduct(formData);
    setProducts(updated);
    setIsModalOpen(false);
  };

  const handleDelete = (id) => {
    if (window.confirm('Archive this fragrance?')) {
      const updated = productService.deleteProduct(id);
      setProducts(updated);
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-serif">Product Inventory</h2>
        <button 
          onClick={() => handleOpenModal()}
          className="bg-slate-900 text-white px-4 py-2 flex items-center text-sm font-bold uppercase tracking-widest hover:bg-slate-800 transition-colors"
        >
          <Plus size={18} className="mr-2" /> Add Fragrance
        </button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr className="text-[10px] uppercase tracking-[0.2em] font-bold text-slate-400">
              <th className="px-6 py-4">Fragrance</th>
              <th className="px-6 py-4">Category</th>
              <th className="px-6 py-4">Price</th>
              <th className="px-6 py-4">Stock</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {products.map(p => (
              <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center space-x-4">
                    <img src={p.image} className="w-12 h-12 object-cover rounded shadow-sm" />
                    <div>
                      <p className="font-bold text-sm text-slate-800">{p.name}</p>
                      <p className="text-[10px] uppercase text-slate-400">{p.brand}</p>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-slate-600">{p.category}</td>
                <td className="px-6 py-4 text-sm font-medium">${p.price}</td>
                <td className="px-6 py-4">
                  <span className={`text-xs font-bold ${p.stock < 10 ? 'text-red-500' : 'text-slate-600'}`}>
                    {p.stock} units
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex justify-end space-x-3">
                    <button onClick={() => handleOpenModal(p)} className="text-slate-400 hover:text-blue-600">
                      <Edit size={18} />
                    </button>
                    <button onClick={() => handleDelete(p.id)} className="text-slate-400 hover:text-red-600">
                      <Trash2 size={18} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-6">
          <div className="bg-white w-full max-w-lg rounded-2xl p-8 relative overflow-y-auto max-h-[90vh]">
            <button onClick={() => setIsModalOpen(false)} className="absolute top-6 right-6 text-slate-400">
              <X size={24} />
            </button>
            <h3 className="text-2xl font-serif mb-6">{editingProduct ? 'Edit Fragrance' : 'New Fragrance'}</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <input 
                  placeholder="Name" className="input-field text-sm" required
                  value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})}
                />
                <input 
                  placeholder="Brand" className="input-field text-sm" required
                  value={formData.brand} onChange={e => setFormData({...formData, brand: e.target.value})}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <input 
                  type="number" placeholder="Price" className="input-field text-sm" required
                  value={formData.price} onChange={e => setFormData({...formData, price: Number(e.target.value)})}
                />
                <input 
                  type="number" placeholder="Stock" className="input-field text-sm" required
                  value={formData.stock} onChange={e => setFormData({...formData, stock: Number(e.target.value)})}
                />
              </div>
              <select 
                className="input-field text-sm"
                value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})}
              >
                <option>Intense</option>
                <option>Floral</option>
                <option>Fresh</option>
                <option>Woody</option>
              </select>
              <textarea 
                placeholder="Description" className="input-field text-sm h-24 resize-none"
                value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})}
              ></textarea>
              <input 
                placeholder="Image URL" className="input-field text-sm"
                value={formData.image} onChange={e => setFormData({...formData, image: e.target.value})}
              />
              <button type="submit" className="btn-primary w-full mt-4">
                {editingProduct ? 'Update Listing' : 'Publish Fragrance'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductManagement;
