import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ShoppingBag, ArrowLeft, ShieldCheck, Truck } from 'lucide-react';
import { productService } from '../../services/productService';
import { useCart } from '../../context/CartContext';

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const product = productService.getProductById(id);
  const { addToCart } = useCart();
  const [qty, setQty] = useState(1);

  if (!product) return <div>Product not found</div>;

  const handleAddToCart = () => {
    addToCart(product, qty);
    navigate('/cart');
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <button onClick={() => navigate(-1)} className="flex items-center text-xs uppercase tracking-widest mb-12 hover:text-accent transition-colors">
        <ArrowLeft size={16} className="mr-2" /> Back to collection
      </button>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-start">
        <div className="aspect-[4/5] bg-gray-100 overflow-hidden">
          <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
        </div>

        <div className="py-4">
          <span className="text-accent uppercase tracking-widest text-xs font-bold block mb-4">{product.brand}</span>
          <h1 className="text-4xl md:text-5xl font-serif mb-6">{product.name}</h1>
          <p className="text-2xl mb-8">${product.price}</p>
          
          <div className="space-y-6 mb-10">
            <p className="text-gray-600 leading-relaxed italic">{product.description}</p>
            <div className="p-4 border-l-2 border-slate-900 bg-slate-50 text-sm">
              <span className="font-bold">Fragrance Family:</span> {product.category}
            </div>
          </div>

          <div className="flex items-center space-x-6 mb-10">
            <div className="flex items-center border border-gray-300 h-14">
              <button 
                className="w-12 h-full hover:bg-gray-100" 
                onClick={() => setQty(Math.max(1, qty - 1))}
              >-</button>
              <span className="w-12 text-center font-medium">{qty}</span>
              <button 
                className="w-12 h-full hover:bg-gray-100" 
                onClick={() => setQty(qty + 1)}
              >+</button>
            </div>
            <button 
              onClick={handleAddToCart}
              className="btn-primary flex-grow h-14 flex items-center justify-center"
            >
              <ShoppingBag size={18} className="mr-3" /> Add to Shopping Bag
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-8 border-t border-gray-200">
            <div className="flex items-center text-xs text-gray-500">
              <ShieldCheck size={16} className="mr-2 text-slate-900" /> Secure Payment
            </div>
            <div className="flex items-center text-xs text-gray-500">
              <Truck size={16} className="mr-2 text-slate-900" /> Complimentary Shipping
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
