import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { CheckCircle, ArrowRight } from 'lucide-react';

const OrderSuccess = () => {
  const { id } = useParams();

  return (
    <div className="max-w-2xl mx-auto px-6 py-32 text-center">
      <div className="flex justify-center mb-8 text-green-500">
        <CheckCircle size={80} strokeWidth={1} />
      </div>
      <h1 className="text-4xl font-serif mb-4">Your order is confirmed</h1>
      <p className="text-gray-500 mb-2 italic">Ref: {id}</p>
      <p className="text-gray-600 mb-12 max-w-md mx-auto">
        Thank you for choosing Aura Essence. We've sent a confirmation email to you. 
        Your fragrance is being prepared with care in our atelier.
      </p>

      <div className="bg-slate-50 p-6 mb-12 border border-slate-100">
        <h3 className="text-xs uppercase tracking-widest font-bold mb-4">What's Next?</h3>
        <p className="text-sm text-gray-600 leading-relaxed">
          If you selected Bank Transfer, please send proof of payment to our 
          <a href="https://wa.me/1555000111" className="text-accent font-bold ml-1">WhatsApp Support</a>.
        </p>
      </div>

      <Link to="/catalog" className="btn-primary inline-flex items-center">
        Continue Exploring <ArrowRight size={16} className="ml-2" />
      </Link>
    </div>
  );
};

export default OrderSuccess;
