import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Filter, Search } from 'lucide-react';
import { productService } from '../../services/productService';

const Catalog = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  const products = productService.getProducts();

  const categories = ['All', ...new Set(products.map(p => p.category))];

  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                           p.brand.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCat = activeCategory === 'All' || p.category === activeCategory;
      return matchesSearch && matchesCat;
    });
  }, [searchTerm, activeCategory, products]);

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <header className="mb-12">
        <h1 className="text-4xl font-serif mb-4">Discovery Catalog</h1>
        <p className="text-gray-500 italic">Finding your signature has never been easier.</p>
      </header>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-6 mb-12 border-y border-gray-100 py-6">
        <div className="flex-grow relative">
          <Search className="absolute left-0 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input 
            type="text" 
            placeholder="Search fragrances..." 
            className="input-field pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex items-center space-x-4 overflow-x-auto pb-2 md:pb-0">
          <Filter size={18} className="text-gray-400 hidden md:block" />
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-1 text-xs uppercase tracking-widest whitespace-nowrap border ${
                activeCategory === cat ? 'bg-slate-900 text-white border-slate-900' : 'border-gray-200 hover:border-slate-900'
              } transition-colors`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Grid */}
      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-12">
          {filteredProducts.map(product => (
            <Link key={product.id} to={`/product/${product.id}`} className="group">
              <div className="aspect-square overflow-hidden mb-4 relative">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                {product.stock < 10 && (
                  <span className="absolute top-4 right-4 bg-white/90 px-3 py-1 text-[10px] uppercase font-bold tracking-tighter">
                    Limited Stock
                  </span>
                )}
              </div>
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-[10px] text-gray-400 uppercase tracking-widest mb-1">{product.brand}</p>
                  <h3 className="font-serif group-hover:text-accent transition-colors">{product.name}</h3>
                </div>
                <p className="font-medium text-sm">${product.price}</p>
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-slate-50">
          <p className="text-gray-400 italic">No fragrances found matching your criteria.</p>
        </div>
      )}
    </div>
  );
};

export default Catalog;
