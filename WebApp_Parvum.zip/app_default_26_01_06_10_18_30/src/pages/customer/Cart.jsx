import React from 'react';
import { Link } from 'react-router-dom';
import { Trash2, ShoppingBag } from 'lucide-react';
import { useCart } from '../../context/CartContext';

const Cart = () => {
  const { cart, removeFromCart, updateQuantity, cartTotal } = useCart();

  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-6 py-32 text-center">
        <ShoppingBag size={48} className="mx-auto mb-6 text-gray-300" />
        <h2 className="text-3xl font-serif mb-4">Your bag is empty</h2>
        <p className="text-gray-500 mb-8">It seems you haven't discovered your essence yet.</p>
        <Link to="/catalog" className="btn-primary">Browse Collection</Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <h1 className="text-4xl font-serif mb-12">Shopping Bag</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
        <div className="lg:col-span-2">
          <div className="border-b border-gray-200 pb-4 mb-4 hidden md:grid grid-cols-4 text-xs uppercase tracking-widest text-gray-400 font-bold">
            <div className="col-span-2">Product</div>
            <div>Quantity</div>
            <div className="text-right">Total</div>
          </div>

          <div className="space-y-8">
            {cart.map(item => (
              <div key={item.id} className="grid grid-cols-1 md:grid-cols-4 gap-6 items-center">
                <div className="col-span-2 flex items-center space-x-6">
                  <img src={item.image} alt={item.name} className="w-24 h-24 object-cover" />
                  <div>
                    <h3 className="font-serif text-lg">{item.name}</h3>
                    <p className="text-xs text-gray-400 uppercase tracking-widest">{item.brand}</p>
                    <button 
                      onClick={() => removeFromCart(item.id)}
                      className="text-xs text-red-500 mt-2 flex items-center hover:underline"
                    >
                      <Trash2 size={14} className="mr-1" /> Remove
                    </button>
                  </div>
                </div>
                
                <div className="flex items-center border border-gray-200 w-max h-10">
                  <button onClick={() => updateQuantity(item.id, -1)} className="px-3 hover:bg-gray-50">-</button>
                  <span className="w-8 text-center text-sm">{item.quantity}</span>
                  <button onClick={() => updateQuantity(item.id, 1)} className="px-3 hover:bg-gray-50">+</button>
                </div>

                <div className="text-right font-medium">
                  ${(item.price * item.quantity).toFixed(2)}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-slate-50 p-8 h-max">
          <h2 className="text-xl font-serif mb-6">Order Summary</h2>
          <div className="space-y-4 mb-8">
            <div className="flex justify-between text-sm">
              <span>Subtotal</span>
              <span>${cartTotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Shipping</span>
              <span className="text-green-600 font-medium">Complimentary</span>
            </div>
            <div className="border-t border-gray-200 pt-4 flex justify-between font-bold text-lg">
              <span>Total</span>
              <span>${cartTotal.toFixed(2)}</span>
            </div>
          </div>
          <Link to="/checkout" className="btn-primary w-full block text-center">
            Proceed to Checkout
          </Link>
          <div className="mt-6 space-y-2">
            <p className="text-[10px] text-gray-400 text-center uppercase tracking-widest">
              Available methods: Bank Transfer, COD, WhatsApp
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
