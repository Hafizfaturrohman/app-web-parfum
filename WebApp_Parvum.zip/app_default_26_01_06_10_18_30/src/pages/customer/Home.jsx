import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { productService } from '../../services/productService';

const Home = () => {
  const products = productService.getProducts().slice(0, 3);

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center justify-center overflow-hidden">
        <img 
          src="https://images.unsplash.com/photo-1590736704728-f4730bb30770?auto=format&fit=crop&q=80&w=2000" 
          className="absolute inset-0 w-full h-full object-cover brightness-50"
          alt="Perfume bottle"
        />
        <div className="relative z-10 text-center text-white px-6">
          <span className="text-accent uppercase tracking-[0.3em] text-sm mb-4 block">Crafted in France</span>
          <h1 className="text-5xl md:text-7xl font-serif mb-6">Unveil Your Essence</h1>
          <p className="text-lg md:text-xl text-gray-200 mb-8 max-w-2xl mx-auto font-light italic">
            "Scent is the most intense form of memory."
          </p>
          <Link to="/catalog" className="btn-primary bg-white text-slate-900 hover:bg-slate-100 px-10 py-4">
            Explore Collection
          </Link>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-24 px-6 max-w-7xl mx-auto">
        <div className="flex justify-between items-end mb-12">
          <div>
            <h2 className="text-4xl font-serif mb-2">Curated Originals</h2>
            <div className="h-1 w-20 bg-accent"></div>
          </div>
          <Link to="/catalog" className="text-sm uppercase tracking-widest font-bold border-b-2 border-slate-900 pb-1 flex items-center group">
            View All <ArrowRight size={16} className="ml-2 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {products.map(product => (
            <Link key={product.id} to={`/product/${product.id}`} className="group">
              <div className="aspect-[4/5] overflow-hidden mb-6 bg-gray-100">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
              </div>
              <p className="text-xs text-gray-500 uppercase tracking-widest mb-1">{product.brand}</p>
              <h3 className="text-xl font-serif mb-2 group-hover:text-accent transition-colors">{product.name}</h3>
              <p className="text-slate-600 font-medium">${product.price}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* Newsletter / Brand Ethos */}
      <section className="bg-slate-100 py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-serif mb-8 italic">The Aura Promise</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div>
              <h4 className="font-bold text-xs uppercase tracking-widest mb-4">Ethically Sourced</h4>
              <p className="text-sm text-gray-600">We partner directly with farmers to ensure sustainable harvesting of rare ingredients.</p>
            </div>
            <div>
              <h4 className="font-bold text-xs uppercase tracking-widest mb-4">Hand-Poured</h4>
              <p className="text-sm text-gray-600">Each bottle is hand-finished in our Grasse atelier to ensure peak quality.</p>
            </div>
            <div>
              <h4 className="font-bold text-xs uppercase tracking-widest mb-4">Scent Discovery</h4>
              <p className="text-sm text-gray-600">Complimentary samples with every full bottle purchase for your next discovery.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
