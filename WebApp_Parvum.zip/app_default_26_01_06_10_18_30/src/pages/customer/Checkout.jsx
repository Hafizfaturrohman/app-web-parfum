import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import { orderService } from '../../services/orderService';

const Checkout = () => {
  const { cart, cartTotal, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: '',
    address: '',
    city: '',
    paymentMethod: 'Bank Transfer'
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (cart.length === 0) return;

    const order = orderService.createOrder({
      userId: user?.id || 'guest',
      customer: formData,
      items: cart,
      total: cartTotal
    });

    clearCart();
    navigate(`/order-success/${order.id}`);
  };

  if (cart.length === 0) return <div className="text-center py-20">No items in bag to checkout.</div>;

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <h1 className="text-4xl font-serif mb-12">Checkout</h1>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-2 gap-20">
        <div className="space-y-12">
          <section>
            <h2 className="text-xs uppercase tracking-[0.3em] font-bold mb-8 border-b border-gray-100 pb-2">1. Delivery Information</h2>
            <div className="space-y-6">
              <input 
                name="name" value={formData.name} onChange={handleChange}
                placeholder="Full Name" className="input-field" required 
              />
              <div className="grid grid-cols-2 gap-4">
                <input 
                  name="email" value={formData.email} onChange={handleChange}
                  placeholder="Email" className="input-field" required 
                />
                <input 
                  name="phone" value={formData.phone} onChange={handleChange}
                  placeholder="Phone Number" className="input-field" required 
                />
              </div>
              <input 
                name="address" value={formData.address} onChange={handleChange}
                placeholder="Shipping Address" className="input-field" required 
              />
              <input 
                name="city" value={formData.city} onChange={handleChange}
                placeholder="City / Province" className="input-field" required 
              />
            </div>
          </section>

          <section>
            <h2 className="text-xs uppercase tracking-[0.3em] font-bold mb-8 border-b border-gray-100 pb-2">2. Payment Method</h2>
            <div className="space-y-4">
              {['Bank Transfer', 'COD (Cash on Delivery)', 'PayPal'].map(method => (
                <label key={method} className="flex items-center space-x-3 cursor-pointer p-4 border border-gray-200 hover:bg-slate-50">
                  <input 
                    type="radio" 
                    name="paymentMethod" 
                    value={method}
                    checked={formData.paymentMethod === method}
                    onChange={handleChange}
                    className="accent-slate-900"
                  />
                  <span className="text-sm font-medium">{method}</span>
                </label>
              ))}
            </div>
          </section>
        </div>

        <div>
          <div className="bg-slate-900 text-white p-8">
            <h2 className="text-xl font-serif mb-8 text-accent italic">Order Review</h2>
            <div className="space-y-6 mb-8 max-h-60 overflow-y-auto pr-4">
              {cart.map(item => (
                <div key={item.id} className="flex justify-between items-center text-sm">
                  <div className="flex items-center space-x-4">
                    <img src={item.image} className="w-12 h-12 object-cover" />
                    <div>
                      <p className="font-serif">{item.name}</p>
                      <p className="text-xs text-gray-400">Qty: {item.quantity}</p>
                    </div>
                  </div>
                  <span>${(item.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
            </div>
            
            <div className="border-t border-slate-700 pt-6 space-y-4">
              <div className="flex justify-between text-sm text-gray-400">
                <span>Shipping</span>
                <span>FREE</span>
              </div>
              <div className="flex justify-between text-xl font-serif">
                <span>Grand Total</span>
                <span>${cartTotal.toFixed(2)}</span>
              </div>
            </div>

            <button type="submit" className="w-full mt-10 bg-accent hover:bg-yellow-600 text-slate-900 font-bold py-4 uppercase tracking-widest text-xs transition-colors">
              Confirm Order
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default Checkout;
