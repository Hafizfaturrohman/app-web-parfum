import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    try {
      const user = login(email, password);
      if (user.role === 'admin') navigate('/admin');
      else navigate('/');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="max-w-md mx-auto px-6 py-24">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-serif mb-4 uppercase tracking-widest">Sign In</h1>
        <p className="text-gray-400 italic">Welcome back to Aura Essence</p>
      </div>

      <div className="bg-white p-10 border border-gray-100 shadow-sm">
        {error && (
          <div className="bg-red-50 text-red-600 p-4 mb-6 text-xs uppercase tracking-tight">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-8">
          <div>
            <label className="text-xs font-bold uppercase tracking-widest text-gray-400 block mb-2">Email Address</label>
            <input 
              type="email" required className="input-field" 
              value={email} onChange={(e) => setEmail(e.target.value)}
              placeholder="e.g. admin@aura.com"
            />
          </div>
          <div>
            <label className="text-xs font-bold uppercase tracking-widest text-gray-400 block mb-2">Password</label>
            <input 
              type="password" required className="input-field" 
              value={password} onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
            />
          </div>
          <button type="submit" className="btn-primary w-full py-4 mt-4">
            Enter Boutique
          </button>
        </form>

        <div className="mt-10 pt-8 border-t border-gray-100 text-[10px] text-gray-400 space-y-2">
          <p className="font-bold text-slate-900 uppercase tracking-[0.2em]">Quick Access Guide:</p>
          <p>• Admin: <span className="text-slate-900 font-medium">admin@aura.com / admin123</span></p>
          <p>• Customer: <span className="text-slate-900 font-medium">customer@example.com / password</span></p>
        </div>
      </div>
    </div>
  );
};

export default Login;
