import { INITIAL_PRODUCTS } from './data';

const STORAGE_KEY = 'aura_essence_products';

export const productService = {
  getProducts: () => {
    const products = localStorage.getItem(STORAGE_KEY);
    if (!products) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_PRODUCTS));
      return INITIAL_PRODUCTS;
    }
    return JSON.parse(products);
  },

  getProductById: (id) => {
    const products = productService.getProducts();
    return products.find(p => p.id === id);
  },

  saveProduct: (product) => {
    const products = productService.getProducts();
    let updatedProducts;
    if (product.id) {
      updatedProducts = products.map(p => p.id === product.id ? product : p);
    } else {
      const newProduct = { ...product, id: Date.now().toString() };
      updatedProducts = [...products, newProduct];
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedProducts));
    return updatedProducts;
  },

  deleteProduct: (id) => {
    const products = productService.getProducts();
    const updatedProducts = products.filter(p => p.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedProducts));
    return updatedProducts;
  }
};
