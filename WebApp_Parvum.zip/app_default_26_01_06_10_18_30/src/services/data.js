export const INITIAL_PRODUCTS = [
  {
    id: '1',
    name: 'Midnight Oud',
    brand: 'Aura Signature',
    price: 185,
    description: 'A mysterious and deep fragrance with notes of agarwood, saffron, and velvet rose.',
    category: 'Intense',
    stock: 12,
    image: 'https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: '2',
    name: 'Velvet Jasmine',
    brand: 'Aura Signature',
    price: 145,
    description: 'Pure Sambac jasmine blended with silk musk and a hint of green tea.',
    category: 'Floral',
    stock: 24,
    image: 'https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: '3',
    name: 'Desert Bloom',
    brand: 'Nomad Series',
    price: 165,
    description: 'A refreshing take on desert flora, featuring neroli, prickly pear, and warm sand accord.',
    category: 'Fresh',
    stock: 8,
    image: 'https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: '4',
    name: 'Amber Dusk',
    brand: 'Nomad Series',
    price: 195,
    description: 'Smoky amber paired with vanilla bean and charred cedarwood.',
    category: 'Woody',
    stock: 5,
    image: 'https://images.unsplash.com/photo-1523293182086-7651a899d37f?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: '5',
    name: 'Santal Solis',
    brand: 'Essence Pure',
    price: 130,
    description: 'Creamy Australian sandalwood with a bright burst of Calabrian bergamot.',
    category: 'Woody',
    stock: 15,
    image: 'https://images.unsplash.com/photo-1616948055600-8f940d45c6e2?auto=format&fit=crop&q=80&w=800'
  }
];
