const STORAGE_KEY = 'aura_essence_orders';

export const orderService = {
  getOrders: () => {
    const orders = localStorage.getItem(STORAGE_KEY);
    return orders ? JSON.parse(orders) : [];
  },

  createOrder: (orderData) => {
    const orders = orderService.getOrders();
    const newOrder = {
      ...orderData,
      id: `ORD-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
      status: 'Pending',
      createdAt: new Date().toISOString()
    };
    const updatedOrders = [newOrder, ...orders];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedOrders));
    return newOrder;
  },

  updateOrderStatus: (orderId, status) => {
    const orders = orderService.getOrders();
    const updatedOrders = orders.map(o => o.id === orderId ? { ...o, status } : o);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedOrders));
    return updatedOrders;
  },

  getOrderByUserId: (userId) => {
    const orders = orderService.getOrders();
    return orders.filter(o => o.userId === userId);
  }
};
