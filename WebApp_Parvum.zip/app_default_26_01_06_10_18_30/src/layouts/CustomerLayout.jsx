import React from 'react';
import { Link, Outlet, useNavigate } from 'react-router-dom';
import { ShoppingBag, User, LogOut, Menu, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';

const CustomerLayout = () => {
  const { user, logout } = useAuth();
  const { cart } = useCart();
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="min-h-screen flex flex-col">
      <nav className="glass-nav sticky top-0 z-50 px-6 py-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <Link to="/" className="text-2xl font-serif tracking-widest uppercase">Aura Essence</Link>
          
          <div className="hidden md:flex space-x-8 items-center text-sm font-medium uppercase tracking-wider">
            <Link to="/" className="hover:text-accent transition-colors">Home</Link>
            <Link to="/catalog" className="hover:text-accent transition-colors">Catalog</Link>
            {user?.role === 'admin' && (
              <Link to="/admin" className="text-accent font-bold">Admin Panel</Link>
            )}
            <div className="flex items-center space-x-6 pl-4 border-l border-gray-200">
              <Link to="/cart" className="relative group">
                <ShoppingBag size={20} className="group-hover:text-accent transition-colors" />
                {cart.length > 0 && (
                  <span className="absolute -top-2 -right-2 bg-slate-900 text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center">
                    {cart.reduce((a, b) => a + b.quantity, 0)}
                  </span>
                )}
              </Link>
              {user ? (
                <div className="flex items-center space-x-4">
                  <span className="text-xs text-gray-500 lowercase">@{user.name}</span>
                  <button onClick={handleLogout} className="hover:text-red-500 transition-colors">
                    <LogOut size={18} />
                  </button>
                </div>
              ) : (
                <Link to="/login" className="hover:text-accent transition-colors">
                  <User size={20} />
                </Link>
              )}
            </div>
          </div>

          <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden absolute top-full left-0 w-full bg-white border-b border-gray-100 p-6 flex flex-col space-y-4 shadow-xl">
            <Link to="/" onClick={() => setIsMenuOpen(false)}>Home</Link>
            <Link to="/catalog" onClick={() => setIsMenuOpen(false)}>Catalog</Link>
            <Link to="/cart" onClick={() => setIsMenuOpen(false)}>Cart ({cart.length})</Link>
            {user ? (
               <button onClick={handleLogout} className="text-left">Logout</button>
            ) : (
              <Link to="/login" onClick={() => setIsMenuOpen(false)}>Login</Link>
            )}
          </div>
        )}
      </nav>

      <main className="flex-grow">
        <Outlet />
      </main>

      <footer className="bg-slate-900 text-white py-12 px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <h3 className="font-serif text-2xl mb-4 tracking-widest uppercase">Aura Essence</h3>
            <p className="text-gray-400 max-w-sm mb-6">
              Curating the finest artisanal fragrances from around the globe. Discover your unique scent signature.
            </p>
          </div>
          <div>
            <h4 className="font-bold mb-4 uppercase text-xs tracking-widest">Shop</h4>
            <ul className="text-gray-400 space-y-2 text-sm">
              <li><Link to="/catalog">All Collections</Link></li>
              <li><Link to="/catalog?cat=Woody">Woody</Link></li>
              <li><Link to="/catalog?cat=Floral">Floral</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4 uppercase text-xs tracking-widest">Contact</h4>
            <ul className="text-gray-400 space-y-2 text-sm">
              <li>WhatsApp: +1 (555) 000-111</li>
              <li>Email: contact@aura.essence</li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto border-t border-gray-800 mt-12 pt-8 text-center text-gray-500 text-xs">
          © {new Date().getFullYear()} Aura Essence. All rights reserved.
        </div>
      </footer>
    </div>
  );
};

export default CustomerLayout;
